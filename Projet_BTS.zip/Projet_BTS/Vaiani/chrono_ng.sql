-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Lun 06 Mai 2019 à 14:48
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `chrono_ng`
--

-- --------------------------------------------------------

--
-- Structure de la table `categorie`
--

CREATE TABLE IF NOT EXISTS `categorie` (
  `idGORIE` int(11) NOT NULL AUTO_INCREMENT,
  `nomGORIE` text NOT NULL,
  `sexeGORIE` varchar(1) NOT NULL,
  `age_mini` tinyint(4) NOT NULL,
  `age_maxi` tinyint(4) NOT NULL,
  PRIMARY KEY (`idGORIE`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- Contenu de la table `categorie`
--

INSERT INTO `categorie` (`idGORIE`, `nomGORIE`, `sexeGORIE`, `age_mini`, `age_maxi`) VALUES
(1, 'Baby Athlé', 'T', 0, 6),
(2, 'École d''Athlétisme ', 'T', 7, 9),
(3, 'Poussin ', 'T', 10, 11),
(4, 'Benjamin', 'T', 12, 13),
(5, 'Minime', 'T', 14, 15),
(6, 'Cadet', 'T', 16, 17),
(7, 'Junior', 'M', 18, 19),
(8, 'Junior', 'F', 18, 19),
(9, 'Espoir', 'M', 20, 22),
(10, 'Espoir', 'F', 20, 22),
(11, 'Senior', 'M', 23, 39),
(12, 'Senior', 'F', 23, 39),
(13, 'Master 1 ', 'M', 40, 49),
(14, 'Master 1', 'F', 40, 49),
(15, 'Master 2', 'M', 50, 59),
(16, 'Master 2', 'F', 50, 59),
(17, 'Master 3', 'T', 60, 69),
(18, 'Master 4', 'T', 70, 79),
(19, 'Master 5', 'T', 80, 120);

-- --------------------------------------------------------

--
-- Structure de la table `chat`
--

CREATE TABLE IF NOT EXISTS `chat` (
  `idCHAT` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) NOT NULL,
  `message` text NOT NULL,
  `heure_sms` time NOT NULL,
  `date_sms` date NOT NULL,
  PRIMARY KEY (`idCHAT`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `chrono`
--

CREATE TABLE IF NOT EXISTS `chrono` (
  `idRONO` int(11) NOT NULL AUTO_INCREMENT,
  `idURSE` int(11) NOT NULL,
  `idREUR` int(11) NOT NULL,
  `t_depart` time NOT NULL,
  `t_inter` time NOT NULL DEFAULT '00:00:00',
  `t_arrivee` time NOT NULL DEFAULT '00:00:00',
  `tempsInter` time NOT NULL DEFAULT '00:00:00',
  `tempsFinal` time NOT NULL DEFAULT '00:00:00',
  `difference` time NOT NULL DEFAULT '00:00:00',
  PRIMARY KEY (`idRONO`),
  UNIQUE KEY `idREUR` (`idREUR`),
  KEY `idURSE` (`idURSE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `coureur`
--

CREATE TABLE IF NOT EXISTS `coureur` (
  `idREUR` int(11) NOT NULL AUTO_INCREMENT,
  `nomREUR` text NOT NULL,
  `prenomREUR` text NOT NULL,
  `date_naissance` date NOT NULL,
  `sexeREUR` varchar(1) NOT NULL,
  `idURSE` int(11) NOT NULL,
  `idGORIE` int(11) NOT NULL,
  PRIMARY KEY (`idREUR`),
  KEY `idURSE` (`idURSE`),
  KEY `idGORIE` (`idGORIE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `course`
--

CREATE TABLE IF NOT EXISTS `course` (
  `idURSE` int(11) NOT NULL AUTO_INCREMENT,
  `nomURSE` text NOT NULL,
  `lieuURSE` text NOT NULL,
  `distanceURSE` varchar(5) NOT NULL,
  `dateURSE` date NOT NULL,
  `h_depart` time NOT NULL,
  PRIMARY KEY (`idURSE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `dossard`
--

CREATE TABLE IF NOT EXISTS `dossard` (
  `idSARD` int(11) NOT NULL AUTO_INCREMENT,
  `idURSE` int(11) NOT NULL,
  `idREUR` int(11) NOT NULL,
  `numSARD` int(11) NOT NULL,
  `numRFID` text NOT NULL,
  PRIMARY KEY (`idSARD`),
  UNIQUE KEY `idREUR` (`idREUR`),
  KEY `idURSE` (`idURSE`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 AUTO_INCREMENT=1 ;

--
-- Contraintes pour les tables exportées
--

--
-- Contraintes pour la table `chrono`
--
ALTER TABLE `chrono`
  ADD CONSTRAINT `chrono_ibfk_1` FOREIGN KEY (`idURSE`) REFERENCES `course` (`idURSE`),
  ADD CONSTRAINT `chrono_ibfk_2` FOREIGN KEY (`idREUR`) REFERENCES `coureur` (`idREUR`);

--
-- Contraintes pour la table `coureur`
--
ALTER TABLE `coureur`
  ADD CONSTRAINT `coureur_ibfk_1` FOREIGN KEY (`idURSE`) REFERENCES `course` (`idURSE`),
  ADD CONSTRAINT `coureur_ibfk_2` FOREIGN KEY (`idGORIE`) REFERENCES `categorie` (`idGORIE`);

--
-- Contraintes pour la table `dossard`
--
ALTER TABLE `dossard`
  ADD CONSTRAINT `dossard_ibfk_1` FOREIGN KEY (`idURSE`) REFERENCES `course` (`idURSE`),
  ADD CONSTRAINT `dossard_ibfk_2` FOREIGN KEY (`idREUR`) REFERENCES `coureur` (`idREUR`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
